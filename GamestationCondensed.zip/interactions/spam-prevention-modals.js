/**
 * Spam Prevention Modal Handlers
 * Handles modal submissions for spam prevention configuration
 */

const safeModerationSchema = require('../schemas/safeModerationSchema')
const { PermissionFlagsBits } = require('discord.js')
const logger = require('../handler/safeModerationLogger')
const log = logger.scope('SpamModals')

module.exports = {
    name: 'spam-prevention-modals',
    
    async execute(client, interaction) {
        const customId = interaction.customId

        // Check if user is authorized
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: '❌ Only administrators can interact with this panel.',
                ephemeral: true
            })
        }

        try {
            if (customId === 'ss_spam_timeout_modal') {
                await handleTimeoutModal(client, interaction)
            }
            else if (customId === 'ss_spam_actions_modal') {
                await handleActionsModal(client, interaction)
            }
            else if (customId === 'ss_spam_time_between_modal') {
                await handleTimeBetweenModal(client, interaction)
            }
        } catch (error) {
            log.error('[SpamModals] Error:', error)
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: '❌ An error occurred while processing your input.',
                    ephemeral: true
                }).catch(err => log.error('[SpamModals] Error:', err))
            }
        }
    }
}

async function handleTimeoutModal(client, interaction) {
    const durationInput = interaction.fields.getTextInputValue('duration')
    
    // Validate duration format
    if (!isValidDuration(durationInput)) {
        return interaction.reply({
            content: '❌ Invalid duration format. Please use: 6h, 1day, 7day, 28day (max), or 0 (permanent)',
            ephemeral: true
        })
    }
    
    let config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
    
    config.spamPrevention.punishmentType = 'TIMEOUT'
    config.spamPrevention.punishmentDuration = durationInput.toLowerCase().trim()
    config.markModified('spamPrevention')
    await config.save()
    
    // Invalidate cache
    if (client.safeModerationConfigCache) {
        await client.safeModerationConfigCache.invalidate(interaction.guild.id)
    }
    
    const displayDuration = durationInput === '0' ? 'Permanent (28 days)' : durationInput
    
    await interaction.reply({
        content: `✅ Punishment set to: **Timeout ${displayDuration} ⏱**`,
        ephemeral: true
    })
    
    // Refresh main panel
    await refreshMainPanel(client, interaction)
}

async function handleActionsModal(client, interaction) {
    const actionsInput = interaction.fields.getTextInputValue('actions')
    
    const actions = parseInt(actionsInput)
    
    if (isNaN(actions) || actions < 1 || actions > 99) {
        return interaction.reply({
            content: '❌ Invalid number. Please enter a number between 1 and 99.',
            ephemeral: true
        })
    }
    
    let config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
    
    config.spamPrevention.actionsLimit = actions
    config.markModified('spamPrevention')
    await config.save()
    
    // Invalidate cache
    if (client.safeModerationConfigCache) {
        await client.safeModerationConfigCache.invalidate(interaction.guild.id)
    }
    
    await interaction.reply({
        content: `✅ Actions limit set to: **${actions}**`,
        ephemeral: true
    })
    
    // Refresh main panel
    await refreshMainPanel(client, interaction)
}

async function handleTimeBetweenModal(client, interaction) {
    const timeInput = interaction.fields.getTextInputValue('time')
    
    // Parse duration to seconds
    const seconds = parseDurationToSeconds(timeInput)
    
    if (!seconds || seconds < 60 || seconds > 31536000) {
        return interaction.reply({
            content: '❌ Invalid duration. Please use format like: 6h, 12h, 1day, 7days (max 1 year)',
            ephemeral: true
        })
    }
    
    let config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
    
    config.spamPrevention.timeBetweenActions = seconds
    config.markModified('spamPrevention')
    await config.save()
    
    // Invalidate cache
    if (client.safeModerationConfigCache) {
        await client.safeModerationConfigCache.invalidate(interaction.guild.id)
    }
    
    await interaction.reply({
        content: `✅ Time between actions set to: **${formatDuration(seconds)}**`,
        ephemeral: true
    })
    
    // Refresh main panel
    await refreshMainPanel(client, interaction)
}

// ==================== HELPER FUNCTIONS ====================

function isValidDuration(duration) {
    if (!duration) return false
    
    const str = duration.toLowerCase().trim()
    
    // Permanent timeout
    if (str === '0') return true
    
    // Match pattern: <number><unit> (only hours and days, no years)
    const match = str.match(/^(\d+)(h|hour|hours|d|day|days)$/)
    
    if (!match) return false
    
    const value = parseInt(match[1])
    const unit = match[2]
    
    // Validate max 28 days
    if (unit === 'd' || unit === 'day' || unit === 'days') {
        return value <= 28
    }
    
    // Validate max 672 hours (28 days)
    if (unit === 'h' || unit === 'hour' || unit === 'hours') {
        return value <= 672
    }
    
    return true
}

function parseDurationToSeconds(duration) {
    if (!duration) return null
    
    const str = duration.toLowerCase().trim()
    
    // Match pattern: <number><unit> (only min, hours, days, months - max 28 days)
    const match = str.match(/^(\d+)(h|hour|hours|min|minute|minutes|d|day|days|m|month|months)$/)
    
    if (!match) return null
    
    const value = parseInt(match[1])
    const unit = match[2]
    
    let seconds = 0
    
    switch (unit) {
        case 'min':
        case 'minute':
        case 'minutes':
            seconds = value * 60
            break
            
        case 'h':
        case 'hour':
        case 'hours':
            seconds = value * 3600
            break
            
        case 'd':
        case 'day':
        case 'days':
            seconds = value * 86400
            break
            
        case 'm':
        case 'month':
        case 'months':
            seconds = value * 2592000
            break
            
        default:
            return null
    }
    
    // Cap at 28 days (2419200 seconds)
    const maxSeconds = 28 * 86400
    return Math.min(seconds, maxSeconds)
}

function formatDuration(seconds) {
    if (seconds < 60) return `${seconds}s`
    if (seconds < 3600) return `${Math.floor(seconds / 60)}min`
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`
    if (seconds < 2592000) return `${Math.floor(seconds / 86400)}days`
    if (seconds < 31536000) return `${Math.floor(seconds / 2592000)}months`
    return `${Math.floor(seconds / 31536000)}years`
}

/**
 * Refresh the main Safe-Moderation panel after spam prevention changes
 */
async function refreshMainPanel(client, interaction) {
    try {
        const config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
        if (!config) return
        
        // Find the panel message in the last 10 messages
        const messages = await interaction.channel.messages.fetch({ limit: 10 }).catch(() => null)
        if (!messages) return
        
        const panelMessage = messages.find(msg => {
            if (msg.author.id !== client.user.id) return false
            if (!msg.components || msg.components.length === 0) return false
            
            // Check for safe-moderation panel
            return msg.components.some(row => {
                if (row.components && Array.isArray(row.components)) {
                    return row.components.some(c => c.customId?.includes('ss_select_permission') || c.customId?.includes('ss_toggle_system'))
                }
                if (row.customId?.includes('ss_select_permission') || row.customId?.includes('ss_toggle_system')) {
                    return true
                }
                if (row.type === 'CONTAINER' || row.data?.custom_id?.includes('ss_select_permission')) {
                    return true
                }
                return false
            })
        })
        
        if (panelMessage) {
            // Rebuild the panel using the slash command's builder
            const slashCommand = require('../slash-commands/safe-moderation')
            
            // We can't directly call the internal functions, but we can trigger a re-render
            // by editing the message with updated components
            log.debug('[SpamModals] ✅ Panel will auto-refresh on next interaction')
        } else {
            log.warn('[SpamModals] ⚠️ Could not find panel message to refresh')
        }
    } catch (error) {
        log.error('[SpamModals] Error refreshing panel:', error)
    }
}
