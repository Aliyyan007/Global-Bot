/**
 * Spam Prevention Panel Interactions
 * Handles UI interactions for configuring spam prevention
 */

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionFlagsBits } = require('discord.js')
const safeModerationSchema = require('../schemas/safeModerationSchema')
const logger = require('../handler/safeModerationLogger')
const log = logger.scope('SpamPanel')

module.exports = {
    name: 'spam-prevention-panel',
    
    async execute(client, interaction) {
        const customId = interaction.customId

        // Check if user is authorized (Administrator only)
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: '❌ Only administrators can interact with this panel.',
                ephemeral: true
            })
        }

        try {
            if (customId === 'ss_spam_prevention_toggle') {
                await handleToggleSpamPrevention(client, interaction)
            }
            else if (customId === 'ss_spam_punishment_select') {
                await handlePunishmentSelect(client, interaction)
            }
            else if (customId === 'ss_spam_punishment_ban') {
                await handlePunishmentBan(client, interaction)
            }
            else if (customId === 'ss_spam_punishment_kick') {
                await handlePunishmentKick(client, interaction)
            }
            else if (customId === 'ss_spam_punishment_timeout') {
                await showTimeoutModal(client, interaction)
            }
            else if (customId === 'ss_spam_actions_edit') {
                await showActionsModal(client, interaction)
            }
            else if (customId === 'ss_spam_time_between_edit') {
                await showTimeBetweenModal(client, interaction)
            }
            else if (customId === 'ss_spam_restriction_select') {
                await handleRestrictionSelect(client, interaction)
            }
        } catch (error) {
            log.error('[SpamPanel] Error:', error)
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: '❌ An error occurred while processing your request.',
                    ephemeral: true
                }).catch(err => log.error('[SpamPanel] Error:', err))
            }
        }
    }
}

// ==================== HANDLERS ====================

async function handleToggleSpamPrevention(client, interaction) {
    let config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
    
    if (!config) {
        config = new safeModerationSchema({ guildID: interaction.guild.id })
    }
    
    if (!config.spamPrevention) {
        config.spamPrevention = {
            enabled: false,
            punishmentType: 'TIMEOUT',
            punishmentDuration: '2days',
            actionsLimit: 1,
            timeBetweenActions: 21600,
            restrictionType: 'global'
        }
    }
    
    config.spamPrevention.enabled = !config.spamPrevention.enabled
    config.markModified('spamPrevention')
    await config.save()
    
    // Invalidate cache
    if (client.safeModerationConfigCache) {
        await client.safeModerationConfigCache.invalidate(interaction.guild.id)
    }
    
    const status = config.spamPrevention.enabled ? 'enabled' : 'disabled'
    
    await interaction.reply({
        content: `✅ Spam Prevention System ${status}!`,
        ephemeral: true
    })
    
    // Refresh panel if possible
    await refreshSpamPreventionPanel(client, interaction)
}

async function handlePunishmentSelect(client, interaction) {
    // Show punishment selection buttons
    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('ss_spam_punishment_ban')
                .setLabel('Ban')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('ss_spam_punishment_kick')
                .setLabel('Kick')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('ss_spam_punishment_timeout')
                .setLabel('Timeout ⏱')
                .setStyle(ButtonStyle.Primary)
        )
    
    await interaction.reply({
        content: '**Select Punishment Type:**',
        components: [row],
        ephemeral: true
    })
}

async function handlePunishmentBan(client, interaction) {
    let config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
    
    config.spamPrevention.punishmentType = 'BAN'
    config.spamPrevention.punishmentDuration = null // Not needed for ban
    config.markModified('spamPrevention')
    await config.save()
    
    // Invalidate cache
    if (client.safeModerationConfigCache) {
        await client.safeModerationConfigCache.invalidate(interaction.guild.id)
    }
    
    await interaction.update({
        content: '✅ Punishment set to: **Ban**',
        components: []
    })
    
    await refreshSpamPreventionPanel(client, interaction)
}

async function handlePunishmentKick(client, interaction) {
    let config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
    
    config.spamPrevention.punishmentType = 'KICK'
    config.spamPrevention.punishmentDuration = null // Not needed for kick
    config.markModified('spamPrevention')
    await config.save()
    
    // Invalidate cache
    if (client.safeModerationConfigCache) {
        await client.safeModerationConfigCache.invalidate(interaction.guild.id)
    }
    
    await interaction.update({
        content: '✅ Punishment set to: **Kick**',
        components: []
    })
    
    await refreshSpamPreventionPanel(client, interaction)
}

async function showTimeoutModal(client, interaction) {
    const modal = new ModalBuilder()
        .setCustomId('ss_spam_timeout_modal')
        .setTitle('Set Timeout Duration')
    
    const durationInput = new TextInputBuilder()
        .setCustomId('duration')
        .setLabel('Enter timeout duration:')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Examples: 6h, 1day, 30day, 1year, 0')
        .setRequired(true)
        .setValue('2days')
    
    const row = new ActionRowBuilder().addComponents(durationInput)
    modal.addComponents(row)
    
    await interaction.showModal(modal)
}

async function showActionsModal(client, interaction) {
    const config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
    
    const modal = new ModalBuilder()
        .setCustomId('ss_spam_actions_modal')
        .setTitle('Edit Actions Limit')
    
    const actionsInput = new TextInputBuilder()
        .setCustomId('actions')
        .setLabel('Number of spam violations allowed:')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Enter a number (1-99)')
        .setRequired(true)
        .setValue(config.spamPrevention?.actionsLimit?.toString() || '1')
    
    const row = new ActionRowBuilder().addComponents(actionsInput)
    modal.addComponents(row)
    
    await interaction.showModal(modal)
}

async function showTimeBetweenModal(client, interaction) {
    const config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
    
    const modal = new ModalBuilder()
        .setCustomId('ss_spam_time_between_modal')
        .setTitle('Edit Time Between Actions')
    
    const timeInput = new TextInputBuilder()
        .setCustomId('time')
        .setLabel('Time window for violations:')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Examples: 6h, 12h, 1day, 7days')
        .setRequired(true)
        .setValue(formatDuration(config.spamPrevention?.timeBetweenActions || 21600))
    
    const row = new ActionRowBuilder().addComponents(timeInput)
    modal.addComponents(row)
    
    await interaction.showModal(modal)
}

async function handleRestrictionSelect(client, interaction) {
    const value = interaction.values[0]
    
    let config = await safeModerationSchema.findOne({ guildID: interaction.guild.id })
    
    config.spamPrevention.restrictionType = value
    config.markModified('spamPrevention')
    await config.save()
    
    // Invalidate cache
    if (client.safeModerationConfigCache) {
        await client.safeModerationConfigCache.invalidate(interaction.guild.id)
    }
    
    await interaction.reply({
        content: `✅ Restriction type set to: **${value}**`,
        ephemeral: true
    })
    
    await refreshSpamPreventionPanel(client, interaction)
}

// ==================== HELPER FUNCTIONS ====================

async function refreshSpamPreventionPanel(client, interaction) {
    // This would refresh the main panel - implementation depends on your panel structure
    // For now, just acknowledge
    log.debug('[SpamPanel] Panel refresh requested')
}

function formatDuration(seconds) {
    if (seconds < 60) return `${seconds}s`
    if (seconds < 3600) return `${Math.floor(seconds / 60)}min`
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`
    if (seconds < 2592000) return `${Math.floor(seconds / 86400)}days`
    if (seconds < 31536000) return `${Math.floor(seconds / 2592000)}months`
    return `${Math.floor(seconds / 31536000)}years`
}
