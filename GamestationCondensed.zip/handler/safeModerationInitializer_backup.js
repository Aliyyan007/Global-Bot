/**
 * Safe Moderation Initializer
 * Loads active restrictions from database on bot startup
 * Reschedules automatic role restorations
 */

const lt = require('long-timeout')
const { retryOperation } = require('./safeDbOperations')

// Store active restoration timeouts
const restorationTimeouts = new Map()

/**
 * Initialize safe-moderation restrictions on bot startup
 * Loads all active restrictions and reschedules their restorations
 * @param {Client} client 
 */
async function initSafeModerationRestrictions(client) {
    console.log('[SafeModeration] Initializing active restrictions...')
    
    try {
        const safeModerationSchema = require('../schemas/safeModerationSchema')
        
        // Get all guilds the bot is in
        const guilds = client.guilds.cache.filter(e => e.available).map(e => e.id)
        
        // Find all configs with active restrictions or dynamic roles
        const configs = await safeModerationSchema.find({
            guildID: { $in: guilds },
            $or: [
                { 'dynamicRestrictionRoles.0': { $exists: true } },
                { 'activeRestrictions.0': { $exists: true } }
            ]
        })
        
        let totalScheduled = 0
        let totalExpired = 0
        let totalCleaned = 0
        
        for (const config of configs) {
            const guild = client.guilds.cache.get(config.guildID)
            if (!guild) continue
            
            // Process dynamic restriction roles
            if (config.dynamicRestrictionRoles && config.dynamicRestrictionRoles.length > 0) {
                const rolesToRemove = []
                
                for (const roleEntry of config.dynamicRestrictionRoles) {
                    try {
                        // Check if the role still exists using role ID
                        const restrictionRole = guild.roles.cache.get(roleEntry.roleId)
                        if (!restrictionRole) {
                            rolesToRemove.push(roleEntry.roleId)
                            totalCleaned++
                            continue
                        }
                        
                        // Check if the user still exists
                        const member = await guild.members.fetch(roleEntry.userId).catch(() => null)
                        if (!member) {
                            await restrictionRole.delete('Safe-Moderation: User left server').catch(() => {})
                            rolesToRemove.push(roleEntry.roleId)
                            totalCleaned++
                            continue
                        }
                        
                        // Check if user still has the restriction role
                        if (!member.roles.cache.has(roleEntry.roleId)) {
                            await restrictionRole.delete('Safe-Moderation: Role removed manually').catch(() => {})
                            rolesToRemove.push(roleEntry.roleId)
                            totalCleaned++
                            continue
                        }
                        
                        // Schedule restoration for each restricted permission
                        for (const actionType of roleEntry.restrictedPermissions) {
                            const permissionConfig = config.permissions[actionType]
                            if (!permissionConfig) continue
                            
                            // Use stored expiry time if available, otherwise calculate
                            let expiresAt
                            if (roleEntry.expiryTimes && roleEntry.expiryTimes[actionType]) {
                                expiresAt = new Date(roleEntry.expiryTimes[actionType])
                            } else {
                                const restrictedAt = roleEntry.createdAt || new Date()
                                const cooldownMs = permissionConfig.cooldown * 1000
                                expiresAt = new Date(restrictedAt.getTime() + cooldownMs)
                            }
                            
                            const timeUntilExpiry = expiresAt.getTime() - Date.now()
                            
                            if (timeUntilExpiry <= 0) {
                                // Already expired, restore immediately
                                await restoreRestriction(
                                    client,
                                    guild,
                                    member,
                                    actionType,
                                    config,
                                    roleEntry
                                )
                                totalExpired++
                            } else {
                                // Schedule future restoration
                                scheduleRestrictionRestoration(
                                    client,
                                    guild,
                                    member,
                                    actionType,
                                    config,
                                    roleEntry,
                                    timeUntilExpiry
                                )
                                totalScheduled++
                            }
                        }
                        
                    } catch (error) {
                        console.error(`[SafeModeration] Error processing role entry:`, error.message)
                    }
                }
                
                // Clean up invalid entries
                if (rolesToRemove.length > 0) {
                    await retryOperation(async () => {
                        // Reload config to avoid version conflicts
                        const safeModerationSchema = require('../schemas/safeModerationSchema')
                        const freshConfig = await safeModerationSchema.findOne({ guildID: config.guildID })
                        if (freshConfig) {
                            freshConfig.dynamicRestrictionRoles = freshConfig.dynamicRestrictionRoles.filter(
                                entry => !rolesToRemove.includes(entry.roleId)
                            )
                            await freshConfig.save()
                        }
                    }, {
                        maxRetries: 5,
                        initialDelay: 100,
                        context: 'SafeModeration Init - Cleanup invalid entries'
                    }).catch(err => {
                        console.error('[SafeModeration] Failed to cleanup invalid entries after retries:', err.message)
                    })
                }
            }
        }
        
        console.log(`[SafeModeration] Initialization complete: ${totalScheduled} scheduled, ${totalExpired} expired, ${totalCleaned} cleaned`)
        
        // Initialize bot quarantine auto-cleanup
        await initBotQuarantineCleanup(client)
        
        // Run initial cleanup of empty restriction roles
        await cleanupEmptyRestrictionRoles(client)
        
    } catch (error) {
        console.error('[SafeModeration] Initialization error:', error)
    }
}

/**
 * Schedule a restriction restoration
 * @param {Client} client 
 * @param {Guild} guild 
 * @param {GuildMember} member 
 * @param {string} actionType 
 * @param {Object} config 
 * @param {Object} roleEntry 
 * @param {number} timeUntilExpiry 
 */
function scheduleRestrictionRestoration(client, guild, member, actionType, config, roleEntry, timeUntilExpiry) {
    const key = `${guild.id}_${member.id}_${roleEntry.roleId}_${actionType}`
    
    console.log(`[SafeModeration] 📅 Scheduling restoration for ${member.user.tag}`)
    console.log(`[SafeModeration] Action: ${actionType}`)
    console.log(`[SafeModeration] Time until expiry: ${Math.round(timeUntilExpiry / 1000)}s (${Math.round(timeUntilExpiry / 60000)}m)`)
    console.log(`[SafeModeration] Will expire at: ${new Date(Date.now() + timeUntilExpiry).toISOString()}`)
    
    // Clear existing timeout if any
    if (restorationTimeouts.has(key)) {
        console.log(`[SafeModeration] ⚠️ Clearing existing timeout for ${key}`)
        lt.clearTimeout(restorationTimeouts.get(key))
    }
    
    const timeoutId = lt.setTimeout(async () => {
        console.log(`[SafeModeration] ⏰ TIMEOUT FIRED for ${member.user.tag} - ${actionType}`)
        console.log(`[SafeModeration] Starting restoration process...`)
        await restoreRestriction(client, guild, member, actionType, config, roleEntry)
        restorationTimeouts.delete(key)
        console.log(`[SafeModeration] ✅ Restoration process completed and timeout removed from map`)
    }, timeUntilExpiry)
    
    restorationTimeouts.set(key, timeoutId)
    console.log(`[SafeModeration] ✅ Timeout scheduled and stored in map (total timeouts: ${restorationTimeouts.size})`)
}

/**
 * Restore a restriction (remove restricted permission, restore role if all done)
 * @param {Client} client 
 * @param {Guild} guild 
 * @param {GuildMember} member 
 * @param {string} actionType 
 * @param {Object} config 
 * @param {Object} roleEntry 
 */
async function restoreRestriction(client, guild, member, actionType, config, roleEntry) {
    try {
        console.log(`[SafeModeration] 🔓 Restoring ${member.user.tag} - ${actionType}`)
        
        // Reload config to get latest data
        const safeModerationSchema = require('../schemas/safeModerationSchema')
        const freshConfig = await safeModerationSchema.findOne({ guildID: guild.id })
        if (!freshConfig) {
            console.log(`[SafeModeration] ⚠️ Config not found`)
            return
        }
        
        // Find the dynamic role entry
        const dynamicRoleEntry = freshConfig.dynamicRestrictionRoles?.find(
            entry => entry.userId === member.id && entry.roleId === roleEntry.roleId
        )
        
        if (!dynamicRoleEntry) {
            console.log(`[SafeModeration] ⚠️ Dynamic role entry not found`)
            return
        }
        
        console.log(`[SafeModeration] 📊 BEFORE removal - Restricted permissions:`, dynamicRoleEntry.restrictedPermissions)
        console.log(`[SafeModeration] 📊 BEFORE removal - Array length:`, dynamicRoleEntry.restrictedPermissions.length)
        console.log(`[SafeModeration] 📊 Action to remove:`, actionType)
        
        // Remove this action from restricted permissions
        const index = dynamicRoleEntry.restrictedPermissions.indexOf(actionType)
        console.log(`[SafeModeration] 📊 Index of action in array:`, index)
        
        if (index > -1) {
            dynamicRoleEntry.restrictedPermissions.splice(index, 1)
            console.log(`[SafeModeration] ✅ Removed action from array`)
        } else {
            console.log(`[SafeModeration] ⚠️ Action not found in array!`)
        }
        
        console.log(`[SafeModeration] 📊 AFTER removal - Restricted permissions:`, dynamicRoleEntry.restrictedPermissions)
        console.log(`[SafeModeration] 📊 AFTER removal - Array length:`, dynamicRoleEntry.restrictedPermissions.length)
        console.log(`[SafeModeration] 📊 Checking if length === 0:`, dynamicRoleEntry.restrictedPermissions.length === 0)
        
        // If no more restrictions, fully restore
        if (dynamicRoleEntry.restrictedPermissions.length === 0) {
            console.log(`[SafeModeration] 🔓 No more restrictions, fully restoring`)
            console.log(`[SafeModeration] 🔓 Taking DELETE path`)
            
            const restrictionRole = guild.roles.cache.get(roleEntry.roleId)
            const originalRole = guild.roles.cache.get(roleEntry.originalRoleId)
            
            console.log(`[SafeModeration] 📋 Restriction role: ${restrictionRole ? restrictionRole.name : 'NOT FOUND'}`)
            console.log(`[SafeModeration] 📋 Original role: ${originalRole ? originalRole.name : 'NOT FOUND'}`)
            console.log(`[SafeModeration] 📋 Member has restriction role: ${restrictionRole ? member.roles.cache.has(restrictionRole.id) : 'N/A'}`)
            console.log(`[SafeModeration] 📋 Member has original role: ${originalRole ? member.roles.cache.has(originalRole.id) : 'N/A'}`)
            
            // Remove restriction role from member
            if (restrictionRole && member.roles.cache.has(restrictionRole.id)) {
                await member.roles.remove(restrictionRole, 'Safe-Moderation: All cooldowns expired')
                    .catch(err => console.error('[SafeModeration] Error removing restriction role:', err.message))
                console.log(`[SafeModeration] ✅ Removed restriction role from member`)
            } else {
                console.log(`[SafeModeration] ⚠️ Member doesn't have restriction role or role not found`)
            }
            
            // Restore original role
            if (originalRole && !member.roles.cache.has(originalRole.id)) {
                await member.roles.add(originalRole, 'Safe-Moderation: Cooldown expired')
                    .catch(err => console.error('[SafeModeration] Error restoring original role:', err.message))
                console.log(`[SafeModeration] ✅ Restored original role: ${originalRole.name}`)
            } else if (originalRole) {
                console.log(`[SafeModeration] ℹ️ Member already has original role`)
            } else {
                console.log(`[SafeModeration] ⚠️ Original role not found`)
            }
            
            // Check if any other members have this restriction role before deleting
            if (restrictionRole) {
                // Force refresh role members from Discord
                await guild.members.fetch({ force: true }).catch(() => {})
                const roleMembers = guild.members.cache.filter(m => m.roles.cache.has(restrictionRole.id))
                console.log(`[SafeModeration] 📊 Members with restriction role: ${roleMembers.size}`)
                
                if (roleMembers.size === 0) {
                    // No members have this role, safe to delete
                    await restrictionRole.delete('Safe-Moderation: All restrictions expired, no members')
                        .catch(err => console.error('[SafeModeration] Error deleting restriction role:', err.message))
                    console.log(`[SafeModeration] ✅ Deleted restriction role: ${restrictionRole.name}`)
                } else {
                    console.log(`[SafeModeration] ⚠️ Not deleting restriction role - ${roleMembers.size} member(s) still have it`)
                    console.log(`[SafeModeration] Members: ${roleMembers.map(m => m.user.tag).join(', ')}`)
                }
            }
            
            // Remove from config
            freshConfig.dynamicRestrictionRoles = freshConfig.dynamicRestrictionRoles.filter(
                entry => entry.roleId !== roleEntry.roleId
            )
            
            // Send notification
            await sendFullRestorationNotification(guild, member, freshConfig, actionType)
            
        } else {
            // Still has other restrictions - UPDATE ROLE PERMISSIONS
            console.log(`[SafeModeration] 🔄 Still has restrictions: ${dynamicRoleEntry.restrictedPermissions.join(', ')}`)
            console.log(`[SafeModeration] 🔄 Taking EDIT path (partial restoration)`)
            console.log(`[SafeModeration] 📝 Removing expired restriction: ${actionType}`)
            
            const restrictionRole = guild.roles.cache.get(roleEntry.roleId)
            const originalRole = guild.roles.cache.get(roleEntry.originalRoleId)
            
            if (!restrictionRole) {
                console.error(`[SafeModeration] ❌ Restriction role not found: ${roleEntry.roleId}`)
                // Send error notification to managers
                await sendRoleUpdateFailureNotification(guild, member, actionType, freshConfig, 'Restriction role not found')
                return
            }
            
            if (!originalRole) {
                console.error(`[SafeModeration] ❌ Original role not found: ${roleEntry.originalRoleId}`)
                // Send error notification to managers
                await sendRoleUpdateFailureNotification(guild, member, actionType, freshConfig, 'Original role not found')
                return
            }
            
            console.log(`[SafeModeration] 📝 Recalculating permissions for: ${restrictionRole.name}`)
            console.log(`[SafeModeration] 📝 Original role: ${originalRole.name}`)
            console.log(`[SafeModeration] 📝 Remaining restrictions: ${dynamicRoleEntry.restrictedPermissions.join(', ')}`)
            
            const { PermissionFlagsBits } = require('discord.js')
            
            // Get the fastRestrictor to access getPermissionsToRemove
            const fastRestrictor = client.fastRestrictionApplier
            if (!fastRestrictor) {
                console.error(`[SafeModeration] ❌ FastRestrictionApplier not available`)
                await sendRoleUpdateFailureNotification(guild, member, actionType, freshConfig, 'FastRestrictionApplier not available')
                return
            }
            
            // CRITICAL: Collect ALL permissions to remove from ALL remaining restrictions
            const allPermsToRemove = []
            for (const remainingAction of dynamicRoleEntry.restrictedPermissions) {
                const permsForThisAction = fastRestrictor.getPermissionsToRemove(remainingAction)
                console.log(`[SafeModeration] 📊 Permissions to remove for ${remainingAction}: ${permsForThisAction.join(', ')}`)
                allPermsToRemove.push(...permsForThisAction)
            }
            
            // Remove duplicates
            const uniquePermsToRemove = [...new Set(allPermsToRemove)]
            console.log(`[SafeModeration] 📊 Total unique permissions to keep restricted: ${uniquePermsToRemove.join(', ')}`)
            
            // Check if original role has Administrator
            const hasAdministrator = originalRole.permissions.has(PermissionFlagsBits.Administrator)
            
            let newPerms
            
            if (hasAdministrator) {
                // Special handling for Administrator roles
                console.log(`[SafeModeration] ⚠️ Original role has Administrator - granting all permissions except remaining restrictions`)
                
                // Convert permission names to BitField values
                const permsToRemoveValues = uniquePermsToRemove
                    .map(permName => PermissionFlagsBits[permName])
                    .filter(Boolean)
                
                console.log(`[SafeModeration] 📊 Permission values to remove: ${permsToRemoveValues.length}`)
                
                // Get ALL possible Discord permission VALUES
                const allPermissionValues = Object.values(PermissionFlagsBits).filter(val => typeof val === 'bigint')
                
                // Grant ALL permissions except Administrator and remaining restricted ones
                newPerms = allPermissionValues.filter(permValue => 
                    permValue !== PermissionFlagsBits.Administrator && 
                    !permsToRemoveValues.includes(permValue)
                )
                
                console.log(`[SafeModeration] 📊 Granting ${newPerms.length} permissions (excluding Administrator and ${permsToRemoveValues.length} restricted)`)
            } else {
                // Normal handling for non-Administrator roles
                const currentPerms = originalRole.permissions.toArray()
                
                // Remove ALL restricted permissions from original role permissions
                newPerms = currentPerms.filter(perm => 
                    !uniquePermsToRemove.includes(perm) && perm !== 'Administrator'
                )
                
                console.log(`[SafeModeration] 📊 Original permissions: ${currentPerms.length}`)
                console.log(`[SafeModeration] 📊 Permissions to remove: ${uniquePermsToRemove.length}`)
                console.log(`[SafeModeration] 📊 New permissions: ${newPerms.length}`)
            }
            
            // Update the restriction role with new permissions
            console.log(`[SafeModeration] 🔄 Updating restriction role permissions...`)
            
            try {
                await restrictionRole.setPermissions(newPerms, 'Safe-Moderation: Partial restoration')
                console.log(`[SafeModeration] ✅ Restriction role permissions updated successfully`)
                
                // CRITICAL: Verify the update succeeded by refetching the role
                const updatedRole = await guild.roles.fetch(restrictionRole.id, { force: true })
                
                // Verify that restricted permissions were actually removed
                const permsToRemoveValues = uniquePermsToRemove
                    .map(permName => PermissionFlagsBits[permName])
                    .filter(Boolean)
                
                let verificationFailed = false
                for (const permValue of permsToRemoveValues) {
                    if (updatedRole.permissions.has(permValue)) {
                        const permName = Object.keys(PermissionFlagsBits).find(key => PermissionFlagsBits[key] === permValue)
                        console.error(`[SafeModeration] ❌ VERIFICATION FAILED: Role still has ${permName}`)
                        verificationFailed = true
                    }
                }
                
                if (verificationFailed) {
                    console.error(`[SafeModeration] ❌ Role update verification failed - permissions not properly restricted`)
                    console.error(`[SafeModeration] ❌ This usually means Discord API didn't apply the permission changes`)
                    console.error(`[SafeModeration] ❌ Will retry the update...`)
                    
                    // CRITICAL FIX: Retry the update instead of giving up
                    try {
                        // Wait a bit for Discord to sync
                        await new Promise(resolve => setTimeout(resolve, 2000))
                        
                        // Try updating again
                        await restrictionRole.setPermissions(newPerms, 'Safe-Moderation: Partial restoration (retry)')
                        console.log(`[SafeModeration] ✅ Retry successful - permissions updated`)
                        
                        // Verify again
                        const retryVerify = await guild.roles.fetch(restrictionRole.id, { force: true })
                        let retryFailed = false
                        for (const permValue of permsToRemoveValues) {
                            if (retryVerify.permissions.has(permValue)) {
                                retryFailed = true
                                break
                            }
                        }
                        
                        if (retryFailed) {
                            console.error(`[SafeModeration] ❌ Retry also failed - giving up`)
                            await sendRoleUpdateFailureNotification(guild, member, actionType, freshConfig, 'Role update verification failed after retry')
                            // Continue anyway to save config and clear action history
                        } else {
                            console.log(`[SafeModeration] ✅ Retry verification passed`)
                        }
                    } catch (retryError) {
                        console.error(`[SafeModeration] ❌ Retry failed:`, retryError.message)
                        await sendRoleUpdateFailureNotification(guild, member, actionType, freshConfig, retryError.message)
                        // Continue anyway to save config and clear action history
                    }
                } else {
                    console.log(`[SafeModeration] ✅ Verification passed: All restricted permissions removed`)
                }
                
                // Remove expiry time for this action
                if (dynamicRoleEntry.expiryTimes) {
                    delete dynamicRoleEntry.expiryTimes[actionType]
                }
                
                // Send partial restoration notification ONLY if verification passed
                if (!verificationFailed) {
                    await sendPartialRestorationNotification(
                        guild,
                        member,
                        freshConfig,
                        actionType,
                        dynamicRoleEntry.restrictedPermissions
                    )
                }
                
            } catch (error) {
                console.error(`[SafeModeration] ❌ Failed to update restriction role permissions:`, error.message)
                console.error(`[SafeModeration] ❌ Error stack:`, error.stack)
                
                // Send error notification to managers
                await sendRoleUpdateFailureNotification(guild, member, actionType, freshConfig, error.message)
                return
            }
        }
        
        await retryOperation(async () => {
            // Reload config one more time before final save to avoid version conflicts
            const latestConfig = await safeModerationSchema.findOne({ guildID: guild.id })
            if (latestConfig) {
                // Apply the same changes to the latest config
                const latestEntry = latestConfig.dynamicRestrictionRoles?.find(
                    entry => entry.userId === member.id && entry.roleId === roleEntry.roleId
                )
                
                if (latestEntry) {
                    // Remove this action from restricted permissions
                    const idx = latestEntry.restrictedPermissions.indexOf(actionType)
                    if (idx > -1) {
                        latestEntry.restrictedPermissions.splice(idx, 1)
                    }
                    
                    // If no more restrictions, remove the entry
                    if (latestEntry.restrictedPermissions.length === 0) {
                        latestConfig.dynamicRestrictionRoles = latestConfig.dynamicRestrictionRoles.filter(
                            entry => entry.roleId !== roleEntry.roleId
                        )
                    } else {
                        // Remove expiry time for this action
                        if (latestEntry.expiryTimes) {
                            delete latestEntry.expiryTimes[actionType]
                        }
                    }
                }
                
                await latestConfig.save()
            }
        }, {
            maxRetries: 5,
            initialDelay: 100,
            context: 'SafeModeration Restore - Final save'
        }).catch(err => {
            console.error('[SafeModeration] Failed to save restoration after retries:', err.message)
        })
        
        // Clear action history for this specific action
        if (client.safeModerationTracker) {
            await client.safeModerationTracker.clearActions(guild.id, member.id, actionType)
        }
        
        console.log(`[SafeModeration] ✅ Restoration complete`)
        
    } catch (error) {
        console.error('[SafeModeration] Restoration error:', error.message)
    }
}

/**
 * Send full restoration notification
 */
async function sendFullRestorationNotification(guild, member, config, actionType) {
    const { EmbedBuilder, WebhookClient } = require('discord.js')
    
    const actionNames = {
        banMembers: 'Ban Members',
        kickMembers: 'Kick Members',
        timeoutMembers: 'Timeout Members',
        deleteRole: 'Delete Role',
        deleteChannel: 'Delete Channel',
        deleteMessages: 'Delete Messages',
        changeNickname: 'Change Nickname',
        addingMassBots: 'Adding Mass Bots',
        disconnectingMembers: 'Disconnecting Members from VC',
        movingMembers: 'Moving Members from VC',
        mutingMembers: 'Muting Members from VC',
        everyoneHereSpam: '@everyone / @here Spam'
    }
    
    const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('✅ Safe-Moderation: Fully Restored')
        .setDescription(`**${member.user.tag}** has been fully restored after all cooldowns expired.`)
        .addFields(
            { name: 'User', value: `<@${member.id}>`, inline: true },
            { name: 'Last Restriction', value: actionNames[actionType] || actionType, inline: true }
        )
        .setTimestamp()
    
    // Send to channel
    if (config.logChannelId) {
        const channel = guild.channels.cache.get(config.logChannelId)
        if (channel) {
            await channel.send({ embeds: [embed] }).catch(console.error)
        }
    }
    
    // Send to webhook
    if (config.logWebhook) {
        try {
            const webhook = new WebhookClient({ url: config.logWebhook })
            await webhook.send({
                embeds: [embed],
                username: 'Safe-Moderation',
                avatarURL: guild.iconURL()
            })
            webhook.destroy()
        } catch (error) {
            console.error('[SafeModeration] Webhook notification error:', error.message)
        }
    }
}

/**
 * Send partial restoration notification
 */
async function sendPartialRestorationNotification(guild, member, config, actionType, remainingRestrictions) {
    const { EmbedBuilder, WebhookClient } = require('discord.js')
    
    const actionNames = {
        banMembers: 'Ban Members',
        kickMembers: 'Kick Members',
        timeoutMembers: 'Timeout Members',
        deleteRole: 'Delete Role',
        deleteChannel: 'Delete Channel',
        deleteMessages: 'Delete Messages',
        changeNickname: 'Change Nickname',
        addingMassBots: 'Adding Mass Bots',
        disconnectingMembers: 'Disconnecting Members from VC',
        movingMembers: 'Moving Members from VC',
        mutingMembers: 'Muting Members from VC',
        everyoneHereSpam: '@everyone / @here Spam'
    }
    
    const remainingNames = remainingRestrictions.map(r => actionNames[r] || r).join(', ')
    
    const embed = new EmbedBuilder()
        .setColor(0xF39C12)
        .setTitle('⚠️ Safe-Moderation: Partial Restoration')
        .setDescription(`**${member.user.tag}** has been partially restored.`)
        .addFields(
            { name: 'User', value: `<@${member.id}>`, inline: true },
            { name: 'Restored', value: actionNames[actionType] || actionType, inline: true },
            { name: 'Still Restricted', value: remainingNames, inline: false }
        )
        .setTimestamp()
    
    // Send to channel
    if (config.logChannelId) {
        const channel = guild.channels.cache.get(config.logChannelId)
        if (channel) {
            await channel.send({ embeds: [embed] }).catch(console.error)
        }
    }
    
    // Send to webhook
    if (config.logWebhook) {
        try {
            const webhook = new WebhookClient({ url: config.logWebhook })
            await webhook.send({
                embeds: [embed],
                username: 'Safe-Moderation',
                avatarURL: guild.iconURL()
            })
            webhook.destroy()
        } catch (error) {
            console.error('[SafeModeration] Webhook notification error:', error.message)
        }
    }
}

/**
 * Cancel a scheduled restoration (e.g., if manually restored)
 * @param {string} guildId 
 * @param {string} userId 
 * @param {string} roleId 
 * @param {string} actionType 
 */
function cancelRestrictionRestoration(guildId, userId, roleId, actionType) {
    const key = `${guildId}_${userId}_${roleId}_${actionType}`
    
    if (restorationTimeouts.has(key)) {
        lt.clearTimeout(restorationTimeouts.get(key))
        restorationTimeouts.delete(key)
        console.log(`[SafeModeration] ✅ Cancelled restoration: ${key}`)
        return true
    }
    
    return false
}

/**
 * Send role update failure notification to managers
 * @param {Guild} guild 
 * @param {GuildMember} member 
 * @param {string} actionType 
 * @param {Object} config 
 * @param {string} errorMessage 
 */
async function sendRoleUpdateFailureNotification(guild, member, actionType, config, errorMessage) {
    const { EmbedBuilder, WebhookClient } = require('discord.js')
    
    const actionNames = {
        banMembers: 'Ban Members',
        kickMembers: 'Kick Members',
        timeoutMembers: 'Timeout Members',
        deleteRole: 'Delete Role',
        deleteChannel: 'Delete Channel',
        deleteMessages: 'Delete Messages',
        changeNickname: 'Change Nickname',
        addingMassBots: 'Adding Mass Bots',
        disconnectingMembers: 'Disconnecting Members from VC',
        movingMembers: 'Moving Members from VC',
        mutingMembers: 'Muting Members from VC',
        everyoneHereSpam: '@everyone / @here Spam'
    }
    
    const actionName = actionNames[actionType] || actionType
    
    const embed = new EmbedBuilder()
        .setColor(0xE74C3C) // Red
        .setTitle('❌ Safe-Moderation: Role Update Failed')
        .setDescription(`Failed to update restriction role for **${member.user.tag}** during partial restoration.`)
        .addFields(
            { name: 'User', value: `<@${member.id}>`, inline: true },
            { name: 'Action Type', value: actionName, inline: true },
            { name: 'Error', value: errorMessage.substring(0, 1024), inline: false },
            { name: 'Action Required', value: 'Please manually review this restriction using `/safe-moderation manage` or `/clear-restrictions`', inline: false }
        )
        .setTimestamp()
    
    // Build manager role mentions
    let content = ''
    if (config.managerRoles && config.managerRoles.length > 0) {
        const roleMentions = config.managerRoles
            .map(roleId => `<@&${roleId}>`)
            .join(' ')
        content = `${roleMentions} - Role update failed!`
    }
    
    // Try to send via webhook
    if (config.logWebhook) {
        try {
            const webhook = new WebhookClient({ url: config.logWebhook })
            await webhook.send({
                content: content || undefined,
                embeds: [embed],
                username: 'Safe-Moderation',
                avatarURL: guild.iconURL()
            })
            webhook.destroy()
            console.log('[SafeModeration] ✅ Role update failure notification sent')
        } catch (error) {
            console.error('[SafeModeration] ❌ Webhook notification error:', error.message)
        }
    }
    
    // Also try log channel
    if (config.logChannelId) {
        const channel = guild.channels.cache.get(config.logChannelId)
        if (channel) {
            await channel.send({ 
                content: content || undefined,
                embeds: [embed] 
            }).catch(console.error)
        }
    }
}

/**
 * Clean up empty restriction roles
 * Detects roles with no members and removes them from server and database
 * @param {Client} client 
 * @param {string} guildId - Optional guild ID to clean up specific guild
 * @returns {Promise<Object>} Cleanup statistics
 */
async function cleanupEmptyRestrictionRoles(client, guildId = null) {
    try {
        const safeModerationSchema = require('../schemas/safeModerationSchema')
        
        // Get guilds to check
        let guildsToCheck = []
        if (guildId) {
            guildsToCheck = [guildId]
        } else {
            guildsToCheck = client.guilds.cache.filter(e => e.available).map(e => e.id)
        }
        
        // Find all configs with dynamic restriction roles
        const configs = await safeModerationSchema.find({
            guildID: { $in: guildsToCheck },
            'dynamicRestrictionRoles.0': { $exists: true }
        })
        
        let totalChecked = 0
        let totalCleaned = 0
        
        for (const config of configs) {
            const guild = client.guilds.cache.get(config.guildID)
            if (!guild) continue
            
            const rolesToRemove = []
            
            for (const roleEntry of config.dynamicRestrictionRoles) {
                totalChecked++
                
                try {
                    // Check if the role still exists using role ID
                    const restrictionRole = guild.roles.cache.get(roleEntry.roleId)
                    if (!restrictionRole) {
                        rolesToRemove.push(roleEntry.roleId)
                        
                        // Cancel any scheduled restorations for this role
                        if (roleEntry.restrictedPermissions) {
                            for (const actionType of roleEntry.restrictedPermissions) {
                                cancelRestrictionRestoration(guild.id, roleEntry.userId, roleEntry.roleId, actionType)
                            }
                        }
                        
                        totalCleaned++
                        continue
                    }
                    
                    // Check if any member has this role
                    const membersWithRole = guild.members.cache.filter(member => 
                        member.roles.cache.has(roleEntry.roleId)
                    )
                    
                    if (membersWithRole.size === 0) {
                        // No members have this role, clean it up
                        // Cancel any scheduled restorations for this role
                        if (roleEntry.restrictedPermissions) {
                            for (const actionType of roleEntry.restrictedPermissions) {
                                cancelRestrictionRestoration(guild.id, roleEntry.userId, roleEntry.roleId, actionType)
                            }
                        }
                        
                        // Delete the role from Discord
                        await restrictionRole.delete('Safe-Moderation: Automatic cleanup - no members').catch(() => {})
                        
                        rolesToRemove.push(roleEntry.roleId)
                        totalCleaned++
                    }
                    
                } catch (error) {
                    console.error(`[SafeModeration] Error processing role entry:`, error.message)
                }
            }
            
            // Remove cleaned roles from database
            if (rolesToRemove.length > 0) {
                config.dynamicRestrictionRoles = config.dynamicRestrictionRoles.filter(
                    entry => !rolesToRemove.includes(entry.roleId)
                )
                await config.save()
            }
        }
        
        if (totalCleaned > 0) {
            console.log(`[SafeModeration] Cleanup complete: ${totalCleaned}/${totalChecked} roles cleaned`)
        }
        
        return { checked: totalChecked, cleaned: totalCleaned, errors: 0 }
        
    } catch (error) {
        console.error('[SafeModeration] Cleanup error:', error)
        return { checked: 0, cleaned: 0, errors: 1 }
    }
}

/**
 * Initialize bot quarantine auto-cleanup on startup
 * Schedules cleanup for all quarantined bots that are approaching 3 days
 * @param {Client} client 
 */
async function initBotQuarantineCleanup(client) {
    try {
        console.log('[SafeModeration] 🤖 Initializing bot quarantine auto-cleanup...')
        
        const safeModerationSchema = require('../schemas/safeModerationSchema')
        
        // Get all guilds the bot is in
        const guilds = client.guilds.cache.filter(e => e.available).map(e => e.id)
        
        // Find all configs with quarantined bots
        const configs = await safeModerationSchema.find({
            guildID: { $in: guilds },
            'quarantinedBots.0': { $exists: true }
        })
        
        console.log(`[SafeModeration] Found ${configs.length} guilds with quarantined bots`)
        
        let totalScheduled = 0
        let totalCleaned = 0
        
        for (const config of configs) {
            const guild = client.guilds.cache.get(config.guildID)
            if (!guild) {
                console.log(`[SafeModeration] ⚠️ Guild ${config.guildID} not found, skipping`)
                continue
            }
            
            for (const quarantineEntry of config.quarantinedBots) {
                // Skip already approved bots
                if (quarantineEntry.approved) {
                    continue
                }
                
                const threeDaysMs = 3 * 24 * 60 * 60 * 1000
                const addedAt = new Date(quarantineEntry.addedAt)
                const cleanupTime = addedAt.getTime() + threeDaysMs
                const timeUntilCleanup = cleanupTime - Date.now()
                
                if (timeUntilCleanup <= 0) {
                    // Already past 3 days, cleanup immediately
                    console.log(`[SafeModeration] 🧹 Bot ${quarantineEntry.botId} quarantine expired, cleaning up now`)
                    await client.safeModerationManager.autoCleanupBotQuarantine(guild.id, quarantineEntry.botId)
                    totalCleaned++
                } else {
                    // Schedule future cleanup
                    console.log(`[SafeModeration] ⏲️ Scheduling cleanup for bot ${quarantineEntry.botId} in ${Math.round(timeUntilCleanup / 1000)}s`)
                    setTimeout(async () => {
                        await client.safeModerationManager.autoCleanupBotQuarantine(guild.id, quarantineEntry.botId)
                    }, timeUntilCleanup)
                    totalScheduled++
                }
            }
        }
        
        console.log(`[SafeModeration] ✅ Bot quarantine cleanup initialized:`)
        console.log(`  - Scheduled: ${totalScheduled} cleanups`)
        console.log(`  - Cleaned immediately: ${totalCleaned} bots`)
        
    } catch (error) {
        console.error('[SafeModeration] Bot quarantine cleanup initialization error:', error)
    }
}

module.exports = {
    initSafeModerationRestrictions,
    scheduleRestrictionRestoration,
    cancelRestrictionRestoration,
    cleanupEmptyRestrictionRoles,
    restorationTimeouts,
    initBotQuarantineCleanup
}
