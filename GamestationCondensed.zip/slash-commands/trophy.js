const { ApplicationCommandOptionType, Collection } = require("discord.js")
module.exports = {
    name: 'trophy',
    nameLocalizations: {
        'ru': `trophy`,
        'uk': `trophy`,
        'es-ES': `trofeo`
    },
    description: 'Manager of trophy system',
    descriptionLocalizations: {
        'ru': `Менеджер трофеев`,
        'uk': `Менеджер трофеїв`,
        'es-ES': `Administrador del sistema de trofeos`
    },
    options: [
        {
            name: 'give',
            nameLocalizations: {
                'ru': `give`,
                'uk': `give`,
                'es-ES': `otorgar`
            },
            description: 'Give a trophy to the user',
            descriptionLocalizations: {
                'ru': `Выдать трофей пользователю`,
                'uk': `Видати трофей користувачу`,
                'es-ES': `Otorgar un trofeo al usuario`
            },
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'user',
                    nameLocalizations: {
                        'ru': `user`,
                        'uk': `user`,
                        'es-ES': `usuario`
                    },
                    description: 'The user to give a trophy',
                    descriptionLocalizations: {
                        'ru': `Пользователь для выдачи трофея`,
                        'uk': `Користувач для видачі трофею`,
                        'es-ES': `Usuario para otorgar el trofeo`
                    },
                    type: ApplicationCommandOptionType.User,
                    required: true
                },
                {
                    name: 'trophy',
                    nameLocalizations: {
                        'ru': `trophy`,
                        'uk': `trophy`,
                        'es-ES': `trofeo`
                    },
                    description: 'Name of trophy',
                    descriptionLocalizations: {
                        'ru': `Название трофея`,
                        'uk': `Назва трофею`,
                        'es-ES': `Nombre del trofeo`
                    },
                    minLength: 1,
                    maxLength: 60,
                    type: ApplicationCommandOptionType.String,
                    required: true
                }
            ]
        },
        {
            name: 'take',
            nameLocalizations: {
                'ru': `take`,
                'uk': `take`,
                'es-ES': `quitar`
            },
            description: 'Take a trophy from the user',
            descriptionLocalizations: {
                'ru': `Забрать трофей у пользователя`,
                'uk': `Забрати трофей у користувача`,
                'es-ES': `Quitar un trofeo al usuario`
            },
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: 'user',
                    nameLocalizations: {
                        'ru': `user`,
                        'uk': `user`,
                        'es-ES': `usuario`
                    },
                    description: 'User to take a trophy',
                    descriptionLocalizations: {
                        'ru': `Пользователь для снятия трофея`,
                        'uk': `Користувач для зняття трофею`,
                        'es-ES': `Usuario para quitar el trofeo`
                    },
                    type: ApplicationCommandOptionType.User,
                    required: true
                },
                {
                    name: 'trophy',
                    nameLocalizations: {
                        'ru': `trophy`,
                        'uk': `trophy`,
                        'es-ES': `trofeo`
                    },
                    description: 'Name of trophy',
                    descriptionLocalizations: {
                        'ru': `Название трофея`,
                        'uk': `Назва трофею`,
                        'es-ES': `Nombre del trofeo`
                    },
                    minLength: 1,
                    maxLength: 60,
                    type: ApplicationCommandOptionType.String,
                    autocomplete: true,
                    required: true
                }
            ]
        },
    ],
    defaultMemberPermissions: "Administrator",
    dmPermission: false,
    group: `profile-group`,
    guildOnly: true,
    cooldowns: new Collection(),
    /**
     *
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args) => {
        const profile = await client.functions.fetchProfile(client, args.user, interaction.guildId)
        if (args.Subcommand == 'give') {
            if (args.trophy.length > 60) {
                return interaction.reply({ content: `${client.config.emojis.NO} ${client.language({ textId: "Trophy name should not contain more than 60 characters", guildId: interaction.guildId, locale: interaction.locale })}`, flags: ["Ephemeral"] })
            }
            if (profile.trophies?.length >= 10) {
                return interaction.reply({ content: `${client.config.emojis.NO} ${client.language({ textId: "Cannot add more than 10 trophies", guildId: interaction.guildId, locale: interaction.locale })}`, flags: ["Ephemeral"] })
            }
            if (profile.trophies?.some(e => e.toLowerCase() == args.trophy.toLowerCase())) {
                return interaction.reply({ content: `${client.config.emojis.NO} <@${args.user}> ${client.language({ textId: "already has", guildId: interaction.guildId, locale: interaction.locale })} ${args.trophy}`, flags: ["Ephemeral"] })
            }
            if (!profile.trophies) profile.trophies = []
            profile.trophies.push(args.trophy)
            await profile.save().catch(err => console.error(`Failed to save profile ${profile.userID}:`, err))
            return interaction.reply({ content: `${client.config.emojis.YES} ${client.language({ textId: "Trophy", guildId: interaction.guildId, locale: interaction.locale })} ${args.trophy} ${client.language({ textId: "was added to", guildId: interaction.guildId, locale: interaction.locale })} <@${args.user}>` })
        }
        if (args.Subcommand == 'take') {
            const trophies = profile.trophies?.filter(e => e.toLowerCase().includes(args.trophy.toLowerCase())) || []
            if (trophies?.length > 1 && !trophies?.some(e => e.toLowerCase() == args.trophy.toLowerCase())) {
                let result = ""
                for (const trophy of trophies) {
                    result += `> ${trophy}\n`
                }
                return interaction.reply({ content: `${client.config.emojis.block}${client.language({ textId: "Multiple trophies found for your query", guildId: interaction.guildId, locale: interaction.locale })}:\n${result}` }) 
            }
            if (!profile.trophies?.some(e => e.toLowerCase() == args.trophy.toLowerCase())) {
                return interaction.reply({ content: `${client.config.emojis.NO} <@${args.user}> ${client.language({ textId: "does not have trophy", guildId: interaction.guildId, locale: interaction.locale })} ${args.trophy}`, flags: ["Ephemeral"] })
            }
            profile.trophies = profile.trophies.filter(e => e.toLowerCase() !== args.trophy.toLowerCase())
            if (!profile.trophies[0]) profile.trophies = undefined
            await profile.save().catch(err => console.error(`Failed to save profile ${profile.userID}:`, err))
            return interaction.reply({ content: `${client.config.emojis.YES} ${client.language({ textId: "Trophy", guildId: interaction.guildId, locale: interaction.locale })} ${args.trophy} ${client.language({ textId: "was removed from", guildId: interaction.guildId, locale: interaction.locale })} <@${args.user}>` })
        }
    }
}
