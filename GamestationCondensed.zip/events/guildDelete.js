const client = require("../index")
const { Events } = require("discord.js")
const { handleError } = require("../handler/errorHandler")

client.on(Events.GuildDelete, async (guild) => {
    try {
        console.log(`[GuildDelete] Bot removed from: ${guild.name} (${guild.id})`)
        
        // ============================================================
        // BACKUP CLEANUP SYSTEM
        // Schedule deletion of emoji/sticker backups after 10 minutes
        // ============================================================
        if (client.backupCleanupScheduler) {
            client.backupCleanupScheduler.scheduleCleanup(guild.id, guild.name)
        }
        
        // ============================================================
        // EXISTING CLEANUP LOGIC (if any)
        // ============================================================
        // Add any existing guild deletion cleanup here
        
    } catch (error) {
        handleError(error, { 
            ownerId: client.config.discord.ownerId, 
            context: 'GuildDelete Event' 
        })
    }
})
