const client = require("../index")
const { setLanguage } = require(`../handler/language`)
const { Events, ShardClientUtil } = require("discord.js")
const { RewardType } = require("../enums")
const Permission = require("../classes/permission.js")
const Job = require("../classes/job.js")
const Giveaway = require("../classes/giveaway.js")
const Wormhole = require("../classes/wormhole.js")
const Profile = require("../classes/profile.js")
const Item = require("../classes/item.js")
const Achievement = require("../classes/achievement.js")
const IncomeRole = require("../classes/IncomeRole")
const ChannelMultipliers = require("../classes/channelMultipliers")
const Promocode = require("../classes/promocode")
const Autogenerator = require("../classes/promocodeAutogenerator")
const Lot = require("../classes/Lot")
const Settings = require("../classes/Settings")
const { handleError } = require("../handler/errorHandler")

client.on(Events.GuildCreate, async (guild) => {
    try {
        if (client.blacklist(guild.id, "full_ban", "guilds")) return
        
        // ============================================================
        // BACKUP CLEANUP CANCELLATION
        // Cancel scheduled cleanup if bot rejoins the guild
        // ============================================================
        if (client.backupCleanupScheduler) {
            client.backupCleanupScheduler.cancelCleanup(guild.id, guild.name)
        }
        
        let settings = await client.functions.fetchSettings(client, guild.id)
    if (settings.deleteFromDB) {
        settings.deleteFromDB = undefined
        await settings.save()
        const profiles = await client.profileSchema.find({ guildID: guild.id }).lean()
        await Promise.all(profiles.map(async profile => {
            try {
                profile = new Profile(client, profile)
                client.cache.profiles.set(profile.guildID+profile.userID, profile)
            } catch (err) {
                console.error(`Failed to load profile ${profile.userID}:`, err)
            }
        }))
        const items = await client.itemSchema.find({ guildID: guild.id }).lean()
        await Promise.all(items.map(async item => {
            try {
                item = new Item(client, item)
                client.cache.items.set(item.itemID, item)
            } catch (err) {
                console.error(`Failed to load item ${item.itemID}:`, err)
            }
        }))
        const achievements = await client.achievementSchema.find({ guildID: guild.id }).lean()
        await Promise.all(achievements.map(async achievement => {
            try {
                achievement = new Achievement(client, achievement)
                client.cache.achievements.set(achievement.id, achievement)
            } catch (err) {
                console.error(`Failed to load achievement ${achievement.id}:`, err)
            }
        }))
        const permissions = await client.permissionSchema.find({ guildID: guild.id }).lean()
        await Promise.all(permissions.map(async permission => {
            try {
                permission = new Permission(client, permission)
                client.cache.permissions.set(permission.id, permission)
            } catch (err) {
                console.error(`Failed to load permission ${permission.id}:`, err)
            }
        }))
        const jobs = await client.jobSchema.find({ guildID: guild.id }).lean()
        await Promise.all(jobs.map(async job => {
            try {
                job = new Job(client, job)
                client.cache.jobs.set(job.id, job)
            } catch (err) {
                console.error(`Failed to load job ${job.id}:`, err)
            }
        }))
        const wormholes = await client.wormholeSchema.find({ guildID: guild.id }).lean()
        await Promise.all(wormholes.map(async wormhole => {
            try {
                wormhole = new Wormhole(client, wormhole)
                if (wormhole.isEnabled) wormhole.cronJobStart()
                client.cache.wormholes.set(wormhole.wormholeID, wormhole)
            } catch (err) {
                console.error(`Failed to load wormhole ${wormhole.wormholeID}:`, err)
            }
        }))
        const roles = await client.roleSchema.find({ guildID: guild.id }).lean()
        await Promise.all(roles.map(async role => {
            try {
                role = new IncomeRole(client, role)
                client.cache.roles.set(role.id, role)
            } catch (err) {
                console.error(`Failed to load role ${role.id}:`, err)
            }
        }))
        const channels = await client.channelMultipliersSchema.find({ guildID: guild.id }).lean()
        await Promise.all(channels.map(async channel => {
            try {
                channel = new ChannelMultipliers(client, channel)
                client.cache.channels.set(channel.id, channel)
            } catch (err) {
                console.error(`Failed to load channel ${channel.id}:`, err)
            }
        }))
        const promocodes = await client.promocodeSchema.find({ guildID: guild.id }).lean()
        await Promise.all(promocodes.map(async promocode => {
            try {
                promocode = new Promocode(client, promocode)
                if (promocode.resetCronPattern) promocode.cronJobStart()
                if (promocode.deleteDate) promocode.setTimeoutDelete()
                client.cache.promocodes.set(`${promocode.code}_${promocode.guildID}`, promocode)
            } catch (err) {
                console.error(`Failed to load promocode ${promocode.code}:`, err)
            }
        }))
        const autogenerators = await client.promocodeAutogeneratorSchema.find({ guildID: guild.id }).lean()
        await Promise.all(autogenerators.map(async autogenerator => {
            try {
                autogenerator = new Autogenerator(client, autogenerator)
                if (autogenerator.isEnabled) autogenerator.cronJobStart()
                client.cache.promocodeAutogenerators.set(autogenerator.id, autogenerator)
            } catch (err) {
                console.error(`Failed to load autogenerator ${autogenerator.id}:`, err)
            }
        }))
        const lots = await client.marketSchema.find({ guildID: guild.id }).lean()
        await Promise.all(lots.map(async lot => {
            try {
                lot = new Lot(client, lot)
                if (lot.lifeTime) lot.setTimeoutDelete()
                client.cache.lots.set(lot.lotID, lot)
            } catch (err) {
                console.error(`Failed to load lot ${lot.lotID}:`, err)
            }
        }))
        const giveaways = await client.giveawaySchema.find({ guildID: guild.id }).lean()
        await Promise.all(giveaways.map(async giveaway => {
            try {
                giveaway = new Giveaway(client, giveaway)
                if (giveaway.endsTime && giveaway.status === "started") giveaway.setTimeoutEnd()
                if (giveaway.deleteTemp && giveaway.status !== "started") giveaway.setTimeoutDelete()
                client.cache.giveaways.set(giveaway.giveawayID, giveaway)
            } catch (err) {
                console.error(`Failed to load giveaway ${giveaway.giveawayID}:`, err)
            }
        }))
    }
    setLanguage(guild, settings ? settings.language : 'en-US')
    
    // Register guild-specific commands for new guild
    if (client.guildCommandManager) {
        const guildCommands = []
        client.slashCommands.forEach(cmd => {
            if (cmd.guildOnly && !cmd.owner) {
                const commandData = Object.assign({}, cmd)
                delete commandData.group
                delete commandData.permissions
                delete commandData.cooldowns
                delete commandData.run
                delete commandData.owner
                delete commandData.guildOnly
                delete commandData.devGuildId
                guildCommands.push(commandData)
            }
        })
        
        if (guildCommands.length > 0) {
            // Register commands asynchronously (don't block event)
            client.guildCommandManager.onGuildCreate(guild, guildCommands).catch(error => {
                console.error(`[GuildCreate] Failed to register commands for ${guild.name}:`, error)
            })
        }
    }
    } catch (error) {
        handleError(error, { ownerId: client.config.discord.ownerId, context: 'GuildCreate Event' })
    }
})
